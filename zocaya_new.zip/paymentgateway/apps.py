from django.apps import AppConfig


class PaymentgatewayConfig(AppConfig):
    name = 'paymentgateway'
