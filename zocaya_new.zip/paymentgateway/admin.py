from django.contrib import admin
from .models import *
admin.site.register(Plan)
admin.site.register(Subscriptions)
admin.site.register(Donations)
admin.site.register(ProductPurchased)

# Register your models here.
